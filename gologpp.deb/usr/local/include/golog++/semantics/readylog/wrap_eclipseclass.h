#pragma once

#include <eclipseclass.h>
